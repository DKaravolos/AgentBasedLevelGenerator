﻿using UnityEngine;
using System.Collections.Generic;

public class LDCell : MonoBehaviour
{
    public IntVector2 coordinates;
    public bool IsOpen { get { return !closedForm.activeInHierarchy; } }
    public bool HasGrown { get; private set; }
    public bool HasStairs { get; set; }
    public bool Walkable { get { return IsOpen && !HasStairs; } }
    public bool CanChangeColor { get; set; }
    [HideInInspector]
    public LDRoom room;
    [SerializeField]
    private GameObject closedForm;
    [SerializeField]
    private GameObject openForm;
    [SerializeField]
    private GameObject indicator;
    private List<GameObject> additional_objects;

    public LDCell()
    {
        ////we should be able to find these automatically, but I get a weird bug.
        //closedForm = transform.GetChild(0).gameObject;
        //openForm = transform.GetChild(1).gameObject;
        //indicator = transform.GetChild(2).gameObject;
        room = null;
        CanChangeColor = true;
        HasStairs = false;
        HasGrown = false;
        additional_objects = new List<GameObject>();
    }

    public void SetOpen(bool open)
    {
        closedForm.SetActive(!open);
        openForm.SetActive(open);
    }

    public void AddToRoom(LDRoom _room, bool fixColor)
    {
        room = _room;
        room.Add(this);
        openForm.SetActive(true);
        closedForm.SetActive(false);
        if(CanChangeColor)
        {
            openForm.GetComponent<Renderer>().material = room.settings.floorMaterial;  // We only have a floor
            CanChangeColor = fixColor;
        }
        transform.parent = _room.transform;
    }

    public void Highlight()
    {
        indicator.SetActive(true);
    }
    public void UnHighlight()
    {
        indicator.SetActive(false);
    }

    //We might want to not show a cell at all if it is not a usable part of the map
    public void Show()
    {
        gameObject.SetActive(true);
    }

    public void Hide()
    {
        gameObject.SetActive(false);
    }

    public void GrowUp()
    {
        //Either spawn a second block
        GameObject secondBlock = Instantiate(closedForm);
        secondBlock.transform.parent = closedForm.transform.parent;
        secondBlock.transform.localScale = closedForm.transform.localScale;
        secondBlock.transform.position = closedForm.transform.position;
        secondBlock.transform.localPosition += new Vector3(0, 1, 0);
        additional_objects.Add(secondBlock);
        HasGrown = true;
        ////Or increase the size of the closedForm
        //closedForm.transform.localScale = new Vector3(1, 2, 1);
        //closedForm.transform.localPosition += new Vector3(0, 0.5f, 0);
    }

    public void CreateNavMeshLink(IntVector2 dir)
    {
        UnityEngine.AI.NavMeshLink link = gameObject.AddComponent<UnityEngine.AI.NavMeshLink>();
        link.area = 2; // 2 is jump
        link.bidirectional = false;
        float radius = UnityEngine.AI.NavMesh.GetSettingsByID(link.agentTypeID).agentRadius;

        //start point:
        float startX = (0.9f * dir.x) * (gameObject.transform.localScale.x * 0.5f); //0.95 because we dont want to be completely on the edge
        float startY = gameObject.transform.localScale.y * 0.5f;
        float startZ = (0.9f * dir.z) * (gameObject.transform.localScale.z * 0.5f);

        //compensate start point for agent radius:
        if (dir.z > 0) // North
            link.startPoint = new Vector3(startX, startY, startZ - radius);
        if (dir.x > 0) // East
            link.startPoint = new Vector3(startX - radius, startY, startZ);
        if (dir.z < 0) // South
            link.startPoint = new Vector3(startX, startY, startZ + radius);
        if (dir.x < 0) // West
            link.startPoint = new Vector3(startX + radius, startY, startZ);

        //end point:
        link.endPoint = new Vector3(2 * startX, -startY, 2 * startZ);
    }
}
