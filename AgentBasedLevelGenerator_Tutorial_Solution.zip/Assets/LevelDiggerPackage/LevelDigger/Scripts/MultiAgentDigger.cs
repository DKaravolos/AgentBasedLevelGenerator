﻿using System.Collections.Generic;
using System.Collections;
using UnityEngine;

public class MultiAgentDigger : LevelDigger
{
    [Header("Multi-agent options")]
    public List<IntVector2> agentPositions;  // You specify both the nr of agents and their start positions in the editor.
    public List<GridDirection> startDirections;  //Or make a fallback plan in the code, in case the value does not exist

    //*//3.Room variables
    public List<IntVector2> startRoomSizes;  // Make sure you specify the content of all Lists in the Editor
    //*/

    protected List<DiggingAgent> agents;       //This will keep track of the agents.

    protected override void Init()
    {
        base.Init();
        /*
         * Go to LevelDigger and comment line 23 to reveal the basic agent variables.
        2.2.1. Use a for-loop to initialize a DiggingAgent for each position in agentPositions and add it
             to the list of agents, so we can update the agents using a loop.
        2.2.2. If you want, you can give the agent a random startDirection if
             an initial startDirection is not specified in the editor. (check out GridDirection.cs)
        3.2. Add the makeRoomProb variable to the initialization of the agent to tell it how
             often to generate a room.
        */
        agents = new List<DiggingAgent>(agentPositions.Count);
        for (int agent = 0; agent < agentPositions.Count; agent++)
        {
            GridDirection dir;
            if (startDirections.Count <= agentPositions.Count)
                dir = GridDirections.RandomValue;
            else
                dir = startDirections[agent];  //We are assuming that if startDirections exists, its size is equal to nr of agents.
            DiggingAgent da = new DiggingAgent(this, agentPositions[agent], dir, changeDirectionProb, makeRoomProb);
            agents.Add(da);
        }
    }

    public override IEnumerator Generate()
    {
        WaitForSeconds delay = new WaitForSeconds(generationStepDelay);
        Init();

        /* 3.1.1
         * Use an if-statement to check if agents should start by creating a room.
            If so, loop through all agents and create a room,
            which size is either defined in the editor or has a random size if nothing is defined.
         * If you want you can use the variable roomSettings to give the start room a color based on the index of the agent.
         * Make sure to show the agent position and use a yield statement to show this step
            to the user.
         */
        //Create spawn rooms
        if (startWithRoom)
        {
            for (int agent = 0; agent < agents.Count; agent++)
            {
                int[] roomSize;
                if (startRoomSizes.Count == 0)
                    roomSize = RandomRoomSize();
                else
                    roomSize = new int[] { startRoomSizes[agent].x, startRoomSizes[agent].z };

                CreateRoom(agents[agent].pos, roomSize, roomSettings[agent % 4 + 1], true);
                agents[agent].CurrentCell.Highlight();
                //agents[agent].stepsDone++;
            }
            yield return delay;
        }


        /* 2.3
         *  Create the main generation loop that runs until maxNrSteps and does the following
            things:
            . Write the current step nr to the command line for debugging purposes
            . Have each agent do a generation step by calling DoNextGenerationStep().
            . Show all agent positions properly at each timestep during generation
              (Hint: use the yield statement)
         */
        ////This is the main loop that digs the level.
        int steps = 0;
        while (steps < maxNrSteps)
        {
            Debug.Log("Step " + steps);
            //Show where the agents are
            foreach (var agent in agents)
                agent.Highlight();
            //pauze this process for visualization in the editor
            yield return delay;
            //Stop showing where the agents are and have each agent perform one step
            foreach (var agent in agents)
            {
                agent.UnHighlight();
                DoNextGenerationStep(agent);
            }
            steps++;
        }
        /* 3.1.2
         * if the agents should stop the generation by creating a room,
            loop through all agents and create a randomly sized room at the current position.
         */
        //Stand in for create second spawn room
        if (endWithRoom)
        {
            for (int agent = 0; agent < agents.Count; agent++)
            {
                CreateRoom(agents[agent].pos, RandomRoomSize());
            }
        }

        /* 5.1
         */
        ////Check whether paths are connected and if not, make a path
        CheckConnectedness();

        ////Optional. Now we have our basic layout. Add extra stuff to the level from here:

        yield return delay;
    }

    protected void DoNextGenerationStep(DiggingAgent agent)
    {
        /*  2.4
         *  Move the agent based on its direction and open that cell.
            Before it moves, change directions if
            a random number says so
            or it would walk off the grid
        */

        //First we move the agent.
        //We change direction by chance or if the next position in the current direction is not in the level.
        if (Random.value < agent.turnProb || !ContainsCoordinates(agent.pos + agent.direction.ToIntVector2()))
        {
            //Randomly move the agent to a new valid position in the level.
            GridDirection newDir = ChangeDirection(agent.pos, agent.direction);
            agent.direction = newDir;
            agent.turnProb = changeDirectionProb;  // 4.2.2
        }
        else   // 4.2.1
        if (dynamicProbabilities)
            agent.turnProb += changeDirDelta;  
        //Now we now the next position! 
        agent.pos += agent.direction.ToIntVector2();

        /* 3.3
         * After the postion of the agent has been updated, generate a random number.
            If it is smaller than agent.roomProb, create a room.
            Otherwise create a corridor, like before.
            Note that CreateRoom() returns a boolean that says whether the room was actually
            created. It is possible that a room is not created, e.g. if does not fit or
            if it overlaps with another room. Determine what to do when room creation fails.
        */

        //Make a room?
        if (Random.value < agent.roomProb)
        {
            bool success = CreateRoom(agent.pos, RandomRoomSize(), paintRoomOnce);
            if (!success)
            {
                agent.OpenCurrentCell();
                if (dynamicProbabilities)
                    agent.roomProb += makeRoomDelta;  //4.2.4
            }
            else
                agent.roomProb = makeRoomProb;  //4.2.3
        }
        else
        {
            //else just open current cell
            agent.OpenCurrentCell();
            if (dynamicProbabilities)
                agent.roomProb += makeRoomDelta;  //4.2.4
        }
        
    }

    protected void CheckConnectedness()
    {
        if (agents.Count == 1)
            return;
        if (agents.Count > 2)
        {
            Debug.LogWarning("Connectedness checking is not implemented for more than two agents");
            return;
        }

        /* 5.2
         * Finish the CheckConnectedness() function based on the HasPathBetween() and
            ConnectPositions() of the LevelDigger class.
         */
        List<IntVector2> visited = new List<IntVector2>();
        if (HasPathBetween(agents[0].pos, agents[1].pos, visited))
        {
            Debug.Log("The map is connected.");
        }
        else
        {
            Debug.Log("Connecting the map...");
            ConnectPositions(agents[0].pos, agents[1].pos);
            Debug.Log("Connecting map is done!");
        }
    }
}
