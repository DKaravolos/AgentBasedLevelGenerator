﻿using UnityEngine;
using System;

[Serializable]
public class LDRoomSettings
{

    public Material floorMaterial; //, wallMaterial;
}