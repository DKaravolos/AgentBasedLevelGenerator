using System;
using UnityEngine;
using System.Text;
using System.IO;

public class MapLogger
{
    public static void WriteMapToFile(LDCell[,] mapCells, IntVector2 mapScale, string logFileName, int seed)
    {
        //Check if folder exists before making file
        string folderName = Path.Combine(Directory.GetCurrentDirectory(), "LogFiles\\Levels");
        if (!Directory.Exists(folderName))
            Directory.CreateDirectory(folderName);
        logFileName = folderName + "\\" + logFileName;
        StringBuilder logBuilder = new StringBuilder(string.Format("Seed:{0}\n", seed));
        int xLength = mapCells.GetLength(0);
        int zLength = mapCells.GetLength(1);
        for (int z = zLength - 1; z >= 0; z--)
        {
            for (int x = 0; x < xLength; x++)
            {
                LDCell cell = mapCells[x, z];
                if (x != 0)
                    logBuilder.Append(",");

                if (cell.HasGrown)
                    logBuilder.Append("2");
                else if (cell.IsOpen)
                    logBuilder.Append("0");
                else
                    logBuilder.Append("1");
            }
            if (z != 0 && z % mapScale.x == 0)
                logBuilder.AppendLine("\r\n----------------------------------------");
            else
                logBuilder.AppendLine();

        }
        using (StreamWriter writer = new StreamWriter(logFileName, false))
        {
            writer.Write(logBuilder.ToString());
            logBuilder.Length = 0; //Clear the logBuilder. I don't know why the method Clear() cannot be found, it should exist...
        }
    }
}
