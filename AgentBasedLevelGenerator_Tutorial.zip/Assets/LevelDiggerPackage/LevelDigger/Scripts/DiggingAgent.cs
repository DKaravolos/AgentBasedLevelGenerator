﻿using System.Collections.Generic;
using System.Collections;

public class DiggingAgent
{
    public IntVector2 pos;
    public GridDirection direction;
    public float turnProb;
    public float roomProb;
    public LDCell CurrentCell { get { return level.GetCell(pos); } }
    public int stepsDone;

    protected float base_changeProb;
    protected float base_roomprob;
    protected LevelDigger level;

    //Material indicatorColor;
    
    public DiggingAgent(LevelDigger _level, IntVector2 position, GridDirection init_direction, float init_changeProb, float init_roomProb=0)
    {
        level = _level;
        pos = position;
        direction = init_direction;
        base_changeProb = turnProb = init_changeProb;
        base_roomprob = roomProb = init_roomProb;
        stepsDone = 0;
    }

    public void OpenCurrentCell()
    {
        if(!CurrentCell.IsOpen)
            CurrentCell.SetOpen(true);
    }

    /* Ideally, the agent has its own visualization which can be moved with the gameobject's transform.position.
     * However, using a 2D grid of integers complicates things a bit, so we will use the cells in the grid to show
     * the agent's position.
     */

    //This shows the position of the agent
    public void Highlight()
    {
        CurrentCell.Highlight();
    }

    //Call this to make the agent disappear from the previous position
    public void UnHighlight()
    {
        CurrentCell.UnHighlight();
    }

}
