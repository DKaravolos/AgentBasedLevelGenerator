﻿///*Agent-based level generation tutorial
//Made by Daniel Karavolos in Unity 2017.1

//####### 1. GameManager ####### 
//The GameManager class will contain prefabs for the level generator
//and the navmesh and instantiate those at the start of the scene.
//It will listen for keystrokes to generate new levels while the scene is running.
//*/


using System.Collections;
using System.Collections.Generic;
using UnityEngine.AI;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManagerLD : MonoBehaviour
{
    public LevelDigger diggerPrefab;
    public NavMeshSurface navmeshPrefab;
    [Range(0, 1)]
    public float minimumOpenness = 0.3f;
    //Privates
    private LevelDigger diggerInstance;
    private NavMeshSurface navmesh;
    public bool useSeed = false;
    public int seed = 0;
    public UnityEngine.UI.Text seedText;

    private void Start()
    {
        navmesh = null;
        seedText = transform.GetChild(0).GetComponentInChildren<UnityEngine.UI.Text>();
        /* 1.1 
         * Initialize the RNG with either 'seed' or a new random number based on the value of 'useSeed'
        */
        seedText.text = string.Format("Seed: {0}.\nPress 'Space' to generate a new level", seed);
        StartCoroutine(BeginGame());
    }

    private void Update()
    {
        /*
         * 1.6 If the user presses 'M', generate a new map based on the next number in the RNG.
         */

        if (Input.GetKeyDown(KeyCode.Space))
        {
            //RestartGame();
            SceneManager.LoadScene(0);
        }
        if (Input.GetKeyDown(KeyCode.B))
        {
            navmesh.BuildNavMesh();
        }
    }

    private IEnumerator BeginGame()
    {
        //Setup main camera
        Camera.main.rect = new Rect(0f, 0f, 1f, 1f);
        Camera.main.clearFlags = CameraClearFlags.Skybox;


        /*
         * 1.2 Create a LevelDigger instance based on the LevelDigger prefab and set its position to the origin of the scene
         * 1.3 Call the LevelDigger's Generate() and use Unity's Coroutine functionality in such a way that you see the intermediate output.
         * Explanation: We do not only want to see the final result, we want to see the agents walking around in the level.
         * 
         * 1.4 Use the LevelDigger's Openness property to generate a new map if the openness does not meet the minimumOpenness.
         */

        //////Setup minimap camera - optional
        //Camera.main.rect = new Rect(0f, 0f, 0.4f, 0.4f);
        //Camera.main.clearFlags = CameraClearFlags.Depth;

        //Build Navmesh
        navmesh = Instantiate(navmeshPrefab) as NavMeshSurface;
        /*
         * 1.5 Once you have the LevelDigger instance, attach the navmeshInstance to the levelDiggerInstance 
         * (i.e make levelDiggerInstance its parent)
         */
        navmesh.BuildNavMesh();

        yield return null; // Once you have implemented 1.3, you don't really need this anymore.
    }

    private void RestartGame()
    {
        StopAllCoroutines();
        Destroy(diggerInstance.gameObject);
        if (navmesh)
            Destroy(navmesh.gameObject);
        StartCoroutine(BeginGame());
    }
}
