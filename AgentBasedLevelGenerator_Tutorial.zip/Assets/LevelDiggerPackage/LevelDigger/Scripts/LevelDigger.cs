﻿//Agent-based level generation tutorial
//Made by Daniel Karavolos in Unity 2017.1
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelDigger : MonoBehaviour
{
    //Public
    [Header("Prefab stuff")]
    public LDCell cellPrefab;
    public GameObject undergroundPrefab;
    public LDRoomSettings[] roomSettings;
    public bool onlyFirstColor = true;

    [Header("Display Properties")]
    public float generationStepDelay = 0.01f;

    [Header("Level Size Properties")]
    public Vector3 cellScale = new Vector3(1, 1, 1);
    public IntVector2 size;

    /* //2.2 Comment this line to reveal basic variables
    [Header("Digging Agent Properties")]
    //Basic variables
    public int maxNrSteps = 50;
    [Range(0f, 1f)]
    public float changeDirectionProb;
    /* // 3. Comment this line to reveal room variables
    // Room variables:
    [Range(0f, 1f)]
    public float makeRoomProb;
    public int minRoomSize = 3;
    public int maxRoomSize = 9;
    public bool startWithRoom = true;
    public bool endWithRoom = false;

    public bool roomsCanOverlap = true;
    public bool paintRoomOnce = true;
    /* //4. Comment this line to reveal dynamic probability variables
    //Dynamic probability variables:
    public bool dynamicProbabilities = true;
    public float changeDirDelta = 0.05f;
    public float makeRoomDelta = 0.05f;
    //*/

    public float Openness
    {
        get
        {
            float nr_open = 0;
            foreach (var cell in cells)
                if (cell.Walkable)
                    nr_open++;
            return nr_open / cells.Length;
        }
    }
    //Privates
    protected LDCell[,] cells;
    protected GameObject underground;
    //[SerializeField]
    protected List<LDRoom> rooms = new List<LDRoom>();
    protected GameObject stairPrefab;
    protected GameObject roomPrefab;

    public IntVector2 RandomCoordinates()
    {
        return new IntVector2(Random.Range(0, size.x), Random.Range(0, size.z));
    }

    /*/ // 3.0 Implement this function
    public int[] RandomRoomSize()
    {
    }
    //*/

    public bool ContainsCoordinates(IntVector2 coordinate)
    {
        return coordinate.x >= 0 && coordinate.x < size.x && coordinate.z >= 0 && coordinate.z < size.z;
    }

    public LDCell GetCell(IntVector2 coordinates)
    {
        return cells[coordinates.x, coordinates.z];
    }

    virtual protected void Init()
    {
        cells = new LDCell[size.x, size.z];
        for (int i = 0; i < size.x; i++)
        {
            for (int j = 0; j < size.z; j++)
            {
                IntVector2 coordinates = new IntVector2(i, j);
                CreateCell(coordinates, cellScale, false);
            }
        }
        //This creates an object below our level. Mainly for debugging size/position problems.
        underground = Instantiate(undergroundPrefab);
        underground.transform.parent = transform;
        underground.transform.localScale = new Vector3(size.x * cellScale.x, 1, size.z * cellScale.z);

        //Get prefabs from resources folder
        stairPrefab = Resources.Load("SmallStairs", typeof(GameObject)) as GameObject;
        roomPrefab = Resources.Load("LDRoom", typeof(GameObject)) as GameObject;
    }
    
    //This is the mainloop called by the GameManager
    virtual public IEnumerator Generate()
    {
        WaitForSeconds delay = new WaitForSeconds(generationStepDelay);
        Init();

        yield return delay;
    }

    virtual protected void DoNextGenerationStep(ref IntVector2 currentPosition, ref GridDirection currentDirection, ref LDCell currentCell,
        ref float turnProb, ref float roomProb)
    {
        Debug.LogWarning("Removed implementation of LevelDigger.DoGenerationStep() for tutorial.");
    }

    protected void OpenCell(IntVector2 position, ref LDCell currentCell)
    {
        currentCell = GetCell(position);
        if (!currentCell.IsOpen)
            currentCell.SetOpen(true);
    }

    protected GridDirection ChangeDirection(IntVector2 currentPosition, GridDirection currentDirection)
    {
        float allowGoBack = 0.01f;
        IntVector2 newPos;
        GridDirection newDir;
        do
        {
            newDir = GridDirections.RandomValue;
            newPos = currentPosition + newDir.ToIntVector2();
        } while (newDir == currentDirection || !ContainsCoordinates(newPos) || (newDir == currentDirection.GetOpposite() && Random.value > allowGoBack));
        return newDir;
    }

    //The CreateCell is only used at the start to setup the complete grid.
    //After that, you can just access the cell and open or close it
    //Special cell content should probably be added when creating "rooms".
    protected LDCell CreateCell(IntVector2 coordinates, Vector3 cellScale, bool open)
    {
        LDCell newCell = Instantiate(cellPrefab) as LDCell;
        newCell.SetOpen(open);
        newCell.transform.localScale = cellScale;
        cells[coordinates.x, coordinates.z] = newCell;
        newCell.name = "LD Cell " + coordinates.x + ", " + coordinates.z;
        newCell.coordinates = coordinates;
        newCell.transform.parent = transform;
        newCell.transform.localPosition = new Vector3(cellScale.x * (coordinates.x - size.x * 0.5f + 0.5f), cellScale.y * 0.5f, cellScale.z * (coordinates.z - size.z * 0.5f + 0.5f));
        return newCell;
    }

    /*//Comment this line to uncomment the CreateRoom functions
    //This function creates rooms. Currently it is only used to give tiles a color.
    //fixColor indicates whether the color of the cell can change after it is assigned to this room.
    protected bool CreateRoom(IntVector2 currentPos, int[] roomSize, bool fixColor=true, bool forcePlacement=false)
    {
        LDRoomSettings setting;
        if (onlyFirstColor)
            setting = roomSettings[0];
        else
            setting = roomSettings[Random.Range(0, roomSettings.Length)];
        return CreateRoom(currentPos, roomSize, setting, fixColor, forcePlacement);
    }

    //This function creates rooms with a specified setting. Currently it is only used to give tiles a color.
    //returns whether it was possible to create a room
    protected bool CreateRoom(IntVector2 currentPos, int[] roomSize, LDRoomSettings setting, bool fixColor, bool forcePlacement=false)
    {
        LDRoom room;
        //Check if there already is a room here. In that case, we might want to add the new cells to that room
        //If there is a room, it is stored in room
        LDRoom overlappedRoom = OverlapsRoom(currentPos, roomSize);
        if (overlappedRoom != null && !roomsCanOverlap && !forcePlacement)
            return false; //not creating overlapping room

        if(overlappedRoom != null && roomsCanOverlap)
        {
            room = overlappedRoom;
            Debug.Log("Expanding Room.");
        }
        else //overlappedRoom == null
        {
            Debug.Log(string.Format("Creating Room of [{0}, {1}], color: {2}", roomSize[0], roomSize[1], setting.floorMaterial.name));
            GameObject roomGo = Instantiate(roomPrefab) as GameObject;    //ScriptableObject.CreateInstance<LDRoom>();
            roomGo.transform.parent = this.transform;
            roomGo.transform.position = GetCell(currentPos).transform.position;
            room = roomGo.GetComponent<LDRoom>();
            room.settings = setting;
            rooms.Add(room);
        }

        //Add cells to the room
        for (int x = currentPos.x - Mathf.CeilToInt(roomSize[0] / 2); x < currentPos.x + Mathf.CeilToInt(roomSize[0] / 2); x++)
            for (int z = currentPos.z - Mathf.CeilToInt(roomSize[1] / 2); z < currentPos.z + Mathf.CeilToInt(roomSize[1] / 2); z++)
            {
                if (ContainsCoordinates(new IntVector2(x,z)))
                    cells[x, z].AddToRoom(room, fixColor);
            }
        return true;
    }
    //*/

    //In output there is either a new room or an existing room
    protected LDRoom OverlapsRoom(IntVector2 currentPos, int[] roomSize)
    {
        for (int x = currentPos.x - Mathf.CeilToInt(roomSize[0] / 2); x < currentPos.x + Mathf.CeilToInt(roomSize[0] / 2); x++)
            for (int z = currentPos.z - Mathf.CeilToInt(roomSize[1] / 2); z < currentPos.z + Mathf.CeilToInt(roomSize[1] / 2); z++)
            {
                if (ContainsCoordinates(new IntVector2(x, z)))
                    if (cells[x, z].room != null)
                    {
                        return cells[x, z].room;
                    }
            }
        return null;
    }

    //Use a simple Depth-First Search to check if there is a path between two points
    protected bool HasPathBetween(IntVector2 firstPos, IntVector2 secondPos, List<IntVector2> visited)
    {
        if (!ContainsCoordinates(firstPos))
            return false;

        if (!GetCell(firstPos).IsOpen || visited.Contains(firstPos))
            return false;

        visited.Add(firstPos);
        if (firstPos.x == secondPos.x && firstPos.z == secondPos.z)
        {
            return true;
        }
        if (HasPathBetween(firstPos + GridDirection.North.ToIntVector2(), secondPos, visited)) {return true; }
        if (HasPathBetween(firstPos + GridDirection.East.ToIntVector2(), secondPos, visited)) { return true; }
        if (HasPathBetween(firstPos + GridDirection.South.ToIntVector2(), secondPos, visited)) { return true; }
        if (HasPathBetween(firstPos + GridDirection.West.ToIntVector2(), secondPos, visited)) { return true; }
        return false;
    }

    //Opens all cells between two points, based on a simple greedy algorithm: first move in X direction, then move in Z direction
    protected void ConnectPositions(IntVector2 pos1, IntVector2 pos2)
    {
        int xDiff = pos2.x - pos1.x;
        if(xDiff > 0)
        {
            for (int i = 0; i < xDiff; i++)
            {
                pos1 += GridDirection.East.ToIntVector2();
                GetCell(pos1).SetOpen(true);
            }
        }
        if (xDiff < 0)
        {
            for (int i = 0; i > xDiff; i--)
            {
                pos1 += GridDirection.West.ToIntVector2();
                GetCell(pos1).SetOpen(true);
            }
        }

        int zDiff = pos2.z - pos1.z;
        if (zDiff > 0)
        {
            for (int i = 0; i < zDiff; i++)
            {
                pos1 += GridDirection.North.ToIntVector2();
                GetCell(pos1).SetOpen(true);
            }
        }
        if (zDiff < 0)
        {
            for (int i = 0; i > zDiff; i--)
            {
                pos1 += GridDirection.South.ToIntVector2();
                GetCell(pos1).SetOpen(true);
            }
        }

    }

    //Some code for adding a second floor that is not part of the tutorial. Feel free to play around with it, though.
    /*
    protected void AddStairs()
    {
        foreach (var cell in cells)
        {
            if (cell.IsOpen) //only spawn stairs on open cells
                foreach (var direction in GridDirections.AllDirections()) //check all directions
                {
                    // if the neighbor is in the grid and it is closed and the surrounding tilesare available: make stairs
                    if (EnoughElevation(cell, direction) && SurroundingsAreFree(cell, direction) && InheritedStairConditions(cell, direction))
                    {
                        if (Random.value < stairSpawnProb)
                        {
                            //Instantiate stair prefab, set right position and rotation and make it part of the cell object.
                            GameObject stairs = Instantiate(stairPrefab);
                            stairs.transform.position = new Vector3(cell.transform.position.x, 0, cell.transform.position.z);
                            stairs.transform.rotation = Quaternion.Euler(new Vector3(0, 90 * (int)direction, 0));
                            stairs.transform.parent = cell.transform;
                            cell.HasStairs = true;
                            break;
                        }
                    }
                }
        }
    }

    protected bool EnoughElevation(LDCell cell, GridDirection direction)
    {
        //Stairs are going to a closed cell
        IntVector2 neighbor = cell.coordinates + direction.ToIntVector2();
        if (!ContainsCoordinates(neighbor) || GetCell(neighbor).IsOpen)
            return false;
        //That tile is also going to a closed cell
        IntVector2 double_neighbor = neighbor + direction.ToIntVector2();
        if (!ContainsCoordinates(double_neighbor) || GetCell(double_neighbor).IsOpen)
            return false;
        return true;
    }

    protected bool SurroundingsAreFree(LDCell cell, GridDirection direction)
    {
        //check normal directions
        for (int i = 1; i <= 3; i++)
        {
            GridDirection dir2 = (GridDirection)(((int)direction + i) % 4);
            //direction = GridDirections.GetNextClockwise(direction);
            IntVector2 neighbor2 = cell.coordinates + dir2.ToIntVector2();

            if (!ContainsCoordinates(neighbor2) || !GetCell(neighbor2).Walkable)
                return false;
        }

        //check diagonals
        IntVector2 opposite = cell.coordinates + direction.GetOpposite().ToIntVector2();
        IntVector2 op_right = opposite + GridDirections.GetNextClockwise(direction).ToIntVector2();
        if (!ContainsCoordinates(op_right) || !GetCell(op_right).Walkable)
            return false;
        IntVector2 op_left = opposite + GridDirections.GetNextCounterclockwise(direction).ToIntVector2();
        if (!ContainsCoordinates(op_left) || !GetCell(op_left).Walkable)
            return false;
        return true;
    }

    protected virtual bool InheritedStairConditions(LDCell cell, GridDirection direction) { return true; }

    protected void CreateSecondFloorWalls()
    {
        foreach (var cell in cells)
        {
            if (!cell.IsOpen) //only elevate closed cells
            {
                //Check Direct neighbors
                bool allDirectNeighborsClosed = true;
                float nrOfNeighborsOpen = 0;
                bool nextToStaircase = false;
                foreach (var direction in GridDirections.AllDirections()) //check all directions
                {
                    IntVector2 neighbor = cell.coordinates + direction.ToIntVector2();
                    if (ContainsCoordinates(neighbor) && GetCell(neighbor).IsOpen)
                    {
                        allDirectNeighborsClosed = false;
                        nrOfNeighborsOpen++;
                        //break;
                        if (GetCell(neighbor).HasStairs)
                            nextToStaircase = true;
                    }   
                }
                //Check Diagonal neighbors
                List<IntVector2> diagonals = new List<IntVector2>();
                diagonals.Add(cell.coordinates + GridDirection.North.ToIntVector2() + GridDirection.East.ToIntVector2());
                diagonals.Add(cell.coordinates + GridDirection.North.ToIntVector2() + GridDirection.West.ToIntVector2());
                diagonals.Add(cell.coordinates + GridDirection.South.ToIntVector2() + GridDirection.East.ToIntVector2());
                diagonals.Add(cell.coordinates + GridDirection.South.ToIntVector2() + GridDirection.West.ToIntVector2());
                foreach (var coord in diagonals)
                {
                    if (ContainsCoordinates(coord) && GetCell(coord).IsOpen)
                    {
                        allDirectNeighborsClosed = false;
                        //break;
                        nrOfNeighborsOpen++;
                    }
                }
                float growProb = 1 - (nrOfNeighborsOpen / 8f);
                float rand = Random.value;
                if (allDirectNeighborsClosed || (!nextToStaircase && Random.value < randomElevationProb))
                {
                    Debug.Log(string.Format("probs: {0} < {1}. Growing Up!", rand, growProb));
                    cell.GrowUp();
                }
            }
        }
    }

    protected void CreateOffMeshLinks()
    {
        foreach (LDCell cell in cells)
        {
            if (cell.IsOpen || cell.HasGrown) //no need to create link for open cells or second floor cells
                continue;
            List<GridDirection> directions = GridDirections.AllDirections();
            foreach (var dir in directions)
            {
                IntVector2 nbr = cell.coordinates + dir.ToIntVector2();
                if (ContainsCoordinates(nbr) && GetCell(nbr).IsOpen && !GetCell(nbr).HasStairs) //create link if this cell is closed and the neighbor is open
                    cell.CreateNavMeshLink(dir.ToIntVector2());
            }
        }
    }
    */
}
